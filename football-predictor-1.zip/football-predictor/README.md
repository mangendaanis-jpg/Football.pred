# ⚽ Football Predictor

Site estático com previsões simples das **5 grandes ligas europeias**:

- Premier League  
- La Liga  
- Serie A  
- Bundesliga  
- Ligue 1  

**Modelo:** forma dos últimos 5 jogos + mando de campo + distribuição de Poisson.

**Indicador de melhor aposta:** destaca a opção com maior probabilidade do modelo (Casa / Empate / Fora) e mostra o nível de confiança (alta / média / baixa) com base na diferença para a segunda opção.

**Dados:** [openfootball/football.json](https://github.com/openfootball/football.json) (domínio público, sem API key).

---

## Como usar (GitHub Pages)

### 1. Crie o repositório

1. Crie um repositório novo no GitHub (ex: `football-predictor`)
2. Faça upload de todos os arquivos desta pasta **ou** clone e faça push:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/football-predictor.git
git push -u origin main
```

### 2. Ative o GitHub Pages

1. Vá em **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: `main` / pasta `/ (root)`
4. Save

O site ficará em:  
`https://SEU_USUARIO.github.io/football-predictor/`

### 3. Atualização automática

O workflow `.github/workflows/update-data.yml` roda **todo dia às 06:00 UTC** e também pode ser disparado manualmente:

1. Aba **Actions**
2. Escolha **Update Football Data**
3. **Run workflow**

Na primeira vez, rode o workflow manualmente para gerar o arquivo `data/matches.json`.

---

## Rodar localmente

```bash
# Gera/atualiza os dados
python scripts/update_data.py

# Serve o site (qualquer servidor estático)
# Exemplo com Python:
python -m http.server 8000
# Abra http://localhost:8000
```

---

## Estrutura

```
├── index.html
├── css/style.css
├── js/app.js
├── data/matches.json          ← gerado pelo script
├── scripts/update_data.py
└── .github/workflows/update-data.yml
```

---

## Aviso

Este é um protótipo estatístico educativo.  
Não constitui aconselhamento de apostas. Futebol tem alta variância.
