(() => {
  "use strict";

  let data = null;
  let currentLeague = null;
  let currentView = "upcoming";

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  async function loadData() {
    try {
      const res = await fetch("data/matches.json?t=" + Date.now());
      if (!res.ok) throw new Error("Falha ao carregar dados");
      data = await res.json();
      init();
    } catch (err) {
      $("#content").innerHTML = `
        <div class="empty">
          <p>Não foi possível carregar os dados.</p>
          <p style="margin-top:0.5rem;font-size:0.85rem">
            Rode o script <code>scripts/update_data.py</code> ou aguarde o GitHub Action.
          </p>
        </div>`;
      console.error(err);
    }
  }

  function init() {
    // Atualização
    const gen = data.generated_at
      ? new Date(data.generated_at).toLocaleString("pt-BR", {
          day: "2-digit",
          month: "short",
          hour: "2-digit",
          minute: "2-digit",
        })
      : "—";
    $("#last-update").textContent = `Atualizado: ${gen}`;

    // Tabs
    const tabs = $("#league-tabs");
    tabs.innerHTML = "";
    data.leagues.forEach((lg, i) => {
      const btn = document.createElement("button");
      btn.className = "tab" + (i === 0 ? " active" : "");
      btn.textContent = `${lg.flag} ${lg.name}`;
      btn.dataset.code = lg.code;
      btn.addEventListener("click", () => selectLeague(lg.code));
      tabs.appendChild(btn);
    });

    currentLeague = data.leagues[0]?.code;
    render();

    // View toggle
    $$('input[name="view"]').forEach((radio) => {
      radio.addEventListener("change", (e) => {
        currentView = e.target.value;
        render();
      });
    });
  }

  function selectLeague(code) {
    currentLeague = code;
    $$(".tab").forEach((t) =>
      t.classList.toggle("active", t.dataset.code === code)
    );
    render();
  }

  function formPills(formStr) {
    if (!formStr || formStr === "—") return "—";
    return formStr
      .split("")
      .map((c) => `<span class="pill ${c}">${c}</span>`)
      .join("");
  }

  function bestBetBadge(m) {
    if (!m.best_bet) return "";
    const levelClass = m.conf_level || "baixa";
    return `
      <div class="best-bet ${levelClass}">
        <span class="best-icon">★</span>
        <span class="best-text">
          Melhor aposta: <strong>${m.best_bet_label}</strong>
          <span class="best-prob">${m.best_bet_prob}%</span>
        </span>
        <span class="conf-tag ${levelClass}">confiança ${m.conf_level}</span>
      </div>
    `;
  }

  function renderUpcoming(matches) {
    if (!matches.length) {
      return `<div class="empty">Nenhum jogo futuro encontrado nesta liga.</div>`;
    }

    return `
      <div class="match-list">
        ${matches
          .map(
            (m) => `
          <article class="match-card ${m.best_bet ? "has-best" : ""}">
            <div class="match-header">
              <span>${m.round || ""}</span>
              <span>${formatDate(m.date)}${m.time ? " · " + m.time : ""}</span>
            </div>
            <div class="match-teams">
              <div class="team home">${shortName(m.home)}</div>
              <div class="vs">vs</div>
              <div class="team away">${shortName(m.away)}</div>
            </div>
            ${bestBetBadge(m)}
            <div class="probs">
              <div class="prob home ${m.best_bet === "H" ? "is-best" : ""}">
                <div class="label">Casa</div>
                <div class="value">${m.prob_home}%</div>
                <div class="bar home"><span style="width:${m.prob_home}%"></span></div>
              </div>
              <div class="prob draw ${m.best_bet === "D" ? "is-best" : ""}">
                <div class="label">Empate</div>
                <div class="value">${m.prob_draw}%</div>
                <div class="bar draw"><span style="width:${m.prob_draw}%"></span></div>
              </div>
              <div class="prob away ${m.best_bet === "A" ? "is-best" : ""}">
                <div class="label">Fora</div>
                <div class="value">${m.prob_away}%</div>
                <div class="bar away"><span style="width:${m.prob_away}%"></span></div>
              </div>
            </div>
            <div class="form-row">
              <span>Forma: <span class="form-pills">${formPills(m.form_home)}</span></span>
              <span>Forma: <span class="form-pills">${formPills(m.form_away)}</span></span>
            </div>
          </article>
        `
          )
          .join("")}
      </div>
    `;
  }

  function renderRecent(matches) {
    if (!matches.length) {
      return `<div class="empty">Nenhum resultado recente.</div>`;
    }

    return `
      <div class="match-list">
        ${matches
          .map(
            (m) => `
          <article class="match-card">
            <div class="match-header">
              <span>${m.round || ""}</span>
              <span>${formatDate(m.date)}</span>
            </div>
            <div class="match-teams">
              <div class="team home">${shortName(m.home)}</div>
              <div class="score">${m.score || "—"}</div>
              <div class="team away">${shortName(m.away)}</div>
            </div>
            <div style="text-align:center;margin-top:0.35rem">
              <span class="result-badge ${m.result}">${
                m.result === "H" ? "Vitória Casa" : m.result === "A" ? "Vitória Fora" : "Empate"
              }</span>
            </div>
          </article>
        `
          )
          .join("")}
      </div>
    `;
  }

  function render() {
    const league = data.leagues.find((l) => l.code === currentLeague);
    if (!league) {
      $("#content").innerHTML = `<div class="empty">Liga não encontrada.</div>`;
      return;
    }

    if (currentView === "upcoming") {
      $("#content").innerHTML = renderUpcoming(league.upcoming);
    } else {
      $("#content").innerHTML = renderRecent(league.recent);
    }
  }

  function formatDate(iso) {
    if (!iso) return "";
    const [y, m, d] = iso.split("-");
    return `${d}/${m}/${y}`;
  }

  function shortName(name) {
    return (name || "")
      .replace(/ FC$/i, "")
      .replace(/ AFC$/i, "")
      .replace(/ & Hove Albion/i, "")
      .replace(/ Hotspur/i, "")
      .trim();
  }

  // Start
  loadData();
})();
