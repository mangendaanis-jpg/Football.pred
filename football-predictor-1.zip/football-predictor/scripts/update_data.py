#!/usr/bin/env python3
"""
Atualiza dados das 5 grandes ligas a partir do openfootball/football.json
e gera previsões simples baseadas em forma recente + mando de campo.
Roda no GitHub Actions (sem API key).
"""

import json
import math
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

SEASON = "2026-27"
BASE = f"https://raw.githubusercontent.com/openfootball/football.json/master/{SEASON}"

LEAGUES = {
    "en.1": {"name": "Premier League", "flag": "🏴󠁧󠁢󠁥󠁮󠁧󠁿"},
    "es.1": {"name": "La Liga", "flag": "🇪🇸"},
    "it.1": {"name": "Serie A", "flag": "🇮🇹"},
    "de.1": {"name": "Bundesliga", "flag": "🇩🇪"},
    "fr.1": {"name": "Ligue 1", "flag": "🇫🇷"},
}

# Fator de mando de campo (gols esperados extras para o mandante)
HOME_ADV = 0.28
# Quantos jogos recentes usar para forma
FORM_N = 5
# Máximo de gols considerados no Poisson
MAX_GOALS = 6


def fetch_json(url: str) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "football-predictor/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode())


def poisson(lmbda: float, k: int) -> float:
    if lmbda <= 0:
        return 1.0 if k == 0 else 0.0
    return math.exp(-lmbda) * (lmbda ** k) / math.factorial(k)


def score_probs(lam_h: float, lam_a: float) -> tuple[float, float, float]:
    """Retorna (P_home, P_draw, P_away) usando Poisson independente."""
    p_h = p_d = p_a = 0.0
    for i in range(MAX_GOALS + 1):
        for j in range(MAX_GOALS + 1):
            p = poisson(lam_h, i) * poisson(lam_a, j)
            if i > j:
                p_h += p
            elif i == j:
                p_d += p
            else:
                p_a += p
    total = p_h + p_d + p_a
    if total <= 0:
        return 0.33, 0.34, 0.33
    return p_h / total, p_d / total, p_a / total


def normalize_score(score) -> list | None:
    """Aceita {'ft': [h,a]} ou [h,a] e devolve [h, a] ou None."""
    if score is None:
        return None
    if isinstance(score, dict):
        ft = score.get("ft")
        if isinstance(ft, (list, tuple)) and len(ft) >= 2:
            return [int(ft[0]), int(ft[1])]
        return None
    if isinstance(score, (list, tuple)) and len(score) >= 2:
        return [int(score[0]), int(score[1])]
    return None


def compute_team_stats(matches: list) -> dict:
    """Calcula média de gols marcados/sofridos (geral + casa/fora) dos últimos FORM_N jogos."""
    by_team = defaultdict(list)

    finished = []
    for m in matches:
        sc = normalize_score(m.get("score"))
        if sc is not None:
            finished.append({**m, "_ft": sc})

    # Ordena por data (mais recente por último)
    finished.sort(key=lambda m: m.get("date", ""))

    for m in finished:
        h, a = m["team1"], m["team2"]
        hg, ag = m["_ft"]
        by_team[h].append({"gf": hg, "ga": ag, "home": True, "date": m["date"]})
        by_team[a].append({"gf": ag, "ga": hg, "home": False, "date": m["date"]})

    stats = {}
    for team, games in by_team.items():
        recent = games[-FORM_N:] if len(games) >= FORM_N else games
        if not recent:
            continue

        gf = sum(g["gf"] for g in recent) / len(recent)
        ga = sum(g["ga"] for g in recent) / len(recent)

        home_games = [g for g in recent if g["home"]]
        away_games = [g for g in recent if not g["home"]]

        home_gf = sum(g["gf"] for g in home_games) / len(home_games) if home_games else gf
        home_ga = sum(g["ga"] for g in home_games) / len(home_games) if home_games else ga
        away_gf = sum(g["gf"] for g in away_games) / len(away_games) if away_games else gf
        away_ga = sum(g["ga"] for g in away_games) / len(away_games) if away_games else ga

        # Forma em pontos (W=3, D=1)
        pts = 0
        form_str = []
        for g in recent:
            if g["gf"] > g["ga"]:
                pts += 3
                form_str.append("W")
            elif g["gf"] == g["ga"]:
                pts += 1
                form_str.append("D")
            else:
                form_str.append("L")

        stats[team] = {
            "gf": round(gf, 2),
            "ga": round(ga, 2),
            "home_gf": round(home_gf, 2),
            "home_ga": round(home_ga, 2),
            "away_gf": round(away_gf, 2),
            "away_ga": round(away_ga, 2),
            "pts_last": pts,
            "played": len(recent),
            "form": "".join(form_str[::-1]),  # mais recente à esquerda
        }
    return stats


def predict_match(home: str, away: str, stats: dict) -> dict:
    """Modelo simples: ataque × defesa + mando de campo."""
    sh = stats.get(home, {})
    sa = stats.get(away, {})

    # Médias de liga aproximadas (fallback)
    avg_gf = 1.35

    home_att = sh.get("home_gf", sh.get("gf", avg_gf))
    home_def = sh.get("home_ga", sh.get("ga", avg_gf))
    away_att = sa.get("away_gf", sa.get("gf", avg_gf))
    away_def = sa.get("away_ga", sa.get("ga", avg_gf))

    # Força relativa (normalizada pela média da liga)
    lam_h = max(0.2, home_att * (away_def / avg_gf) + HOME_ADV)
    lam_a = max(0.15, away_att * (home_def / avg_gf))

    p_h, p_d, p_a = score_probs(lam_h, lam_a)

    probs = {
        "H": round(p_h * 100, 1),
        "D": round(p_d * 100, 1),
        "A": round(p_a * 100, 1),
    }
    # Melhor aposta = maior probabilidade
    best = max(probs, key=probs.get)
    sorted_vals = sorted(probs.values(), reverse=True)
    # Confiança = diferença entre 1º e 2º lugar (em pontos percentuais)
    confidence = round(sorted_vals[0] - sorted_vals[1], 1)

    # Nível visual de confiança
    if confidence >= 25:
        conf_level = "alta"
    elif confidence >= 12:
        conf_level = "média"
    else:
        conf_level = "baixa"

    labels = {"H": "Casa", "D": "Empate", "A": "Fora"}

    return {
        "lambda_home": round(lam_h, 2),
        "lambda_away": round(lam_a, 2),
        "prob_home": probs["H"],
        "prob_draw": probs["D"],
        "prob_away": probs["A"],
        "best_bet": best,
        "best_bet_label": labels[best],
        "best_bet_prob": probs[best],
        "confidence": confidence,
        "conf_level": conf_level,
        "form_home": sh.get("form", "—"),
        "form_away": sa.get("form", "—"),
        "pts_home": sh.get("pts_last", 0),
        "pts_away": sa.get("pts_last", 0),
    }


def process_league(code: str, meta: dict) -> dict:
    url = f"{BASE}/{code}.json"
    print(f"Fetching {url} ...")
    data = fetch_json(url)
    matches = data.get("matches", [])

    stats = compute_team_stats(matches)

    upcoming = []
    recent_results = []

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    for m in matches:
        sc = normalize_score(m.get("score"))
        entry = {
            "round": m.get("round", ""),
            "date": m.get("date", ""),
            "time": m.get("time", ""),
            "home": m.get("team1", ""),
            "away": m.get("team2", ""),
        }

        if sc is not None:
            hg, ag = sc
            entry["score"] = f"{hg}-{ag}"
            entry["result"] = "H" if hg > ag else ("A" if ag > hg else "D")
            recent_results.append(entry)
        else:
            # Jogos futuros (sem placar)
            if m.get("date", "") >= today:
                pred = predict_match(entry["home"], entry["away"], stats)
                entry.update(pred)
                upcoming.append(entry)

    # Ordena próximos por data
    upcoming.sort(key=lambda x: (x["date"], x.get("time", "")))
    recent_results.sort(key=lambda x: x["date"], reverse=True)

    return {
        "code": code,
        "name": meta["name"],
        "flag": meta["flag"],
        "season": SEASON,
        "updated": datetime.now(timezone.utc).isoformat(),
        "upcoming": upcoming[:40],          # próximos ~4 rodadas
        "recent": recent_results[:30],
        "teams": {k: v for k, v in sorted(stats.items())},
    }


def main():
    out_dir = Path(__file__).resolve().parent.parent / "data"
    out_dir.mkdir(exist_ok=True)

    all_data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "season": SEASON,
        "model": "simple-form + home-advantage + poisson",
        "leagues": [],
    }

    for code, meta in LEAGUES.items():
        try:
            league = process_league(code, meta)
            all_data["leagues"].append(league)
            print(f"  → {meta['name']}: {len(league['upcoming'])} upcoming, {len(league['teams'])} teams")
        except Exception as e:
            print(f"  ERROR {code}: {e}")

    out_path = out_dir / "matches.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)

    print(f"\nSaved → {out_path}")


if __name__ == "__main__":
    main()
